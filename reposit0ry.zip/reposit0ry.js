const toggleCheckbox = document.getElementById('modeToggle');
toggleCheckbox.addEventListener('change', () => {
   document.body.classList.toggle('light-mode');
});